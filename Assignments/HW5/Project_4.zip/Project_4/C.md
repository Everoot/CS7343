Some thing about c 
`typedef`: for creating new data type name.